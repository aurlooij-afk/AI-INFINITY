package com.ai.infinity.bridge;

import android.accessibilityservice.AccessibilityService;
import android.view.accessibility.AccessibilityNodeInfo;
import android.view.accessibility.AccessibilityEvent;
import android.os.Bundle;
import java.util.*;

public class BridgeAccessibilityService extends AccessibilityService {
    static volatile BridgeAccessibilityService instance;
    @Override public void onServiceConnected(){instance=this;}
    @Override public void onAccessibilityEvent(AccessibilityEvent e){}
    @Override public void onInterrupt(){}
    @Override public void onDestroy(){if(instance==this)instance=null;super.onDestroy();}
    AccessibilityNodeInfo root(){return getRootInActiveWindow();}
    AccessibilityNodeInfo find(String selector){
        AccessibilityNodeInfo r=root(); if(r==null)return null; String q=selector==null?"":selector.trim();
        if(q.startsWith("text:")){List<AccessibilityNodeInfo> n=r.findAccessibilityNodeInfosByText(q.substring(5)); if(!n.isEmpty())return n.get(0);}
        if(q.startsWith("id:")){List<AccessibilityNodeInfo> n=r.findAccessibilityNodeInfosByViewId(q.substring(3)); if(!n.isEmpty())return n.get(0);}
        if(q.startsWith("desc:")){List<AccessibilityNodeInfo> n=r.findAccessibilityNodeInfosByText(q.substring(5)); if(!n.isEmpty())return n.get(0);}
        return null;
    }
    public boolean click(String selector){AccessibilityNodeInfo n=find(selector); return n!=null && n.isClickable() && n.performAction(AccessibilityNodeInfo.ACTION_CLICK);}
    public boolean type(String selector,String text){AccessibilityNodeInfo n=find(selector); if(n==null){n=root(); if(n==null)return false; n=findEditable(n);} if(n==null)return false; Bundle b=new Bundle(); b.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE,text==null?"":text); return n.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT,b);}
    AccessibilityNodeInfo findEditable(AccessibilityNodeInfo n){if(n.isEditable())return n;for(int i=0;i<n.getChildCount();i++){AccessibilityNodeInfo x=n.getChild(i);if(x!=null){AccessibilityNodeInfo y=findEditable(x);if(y!=null)return y;}}return null;}
    public String extract(){AccessibilityNodeInfo r=root(); if(r==null)return ""; StringBuilder s=new StringBuilder(); walk(r,s); return s.toString().substring(0,Math.min(10000,s.length()));}
    void walk(AccessibilityNodeInfo n,StringBuilder s){CharSequence t=n.getText(); if(t!=null&&t.length()>0)s.append(t).append('\n'); CharSequence d=n.getContentDescription();if(d!=null&&d.length()>0)s.append(d).append('\n');for(int i=0;i<n.getChildCount();i++){AccessibilityNodeInfo x=n.getChild(i);if(x!=null)walk(x,s);}}
}
