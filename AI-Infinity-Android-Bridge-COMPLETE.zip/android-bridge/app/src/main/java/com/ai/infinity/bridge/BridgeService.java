package com.ai.infinity.bridge;

import android.app.*; import android.content.*; import android.graphics.Color; import android.net.Uri; import android.os.*; import android.provider.Settings; import org.json.*; import java.util.*; import java.util.concurrent.*;

public class BridgeService extends Service {
    static final int NOTIFY_ID=8101; volatile boolean running=false; ScheduledExecutorService exec; android.content.SharedPreferences prefs;
    @Override public void onCreate(){super.onCreate();prefs=getSharedPreferences(MainActivity.PREFS,MODE_PRIVATE);createChannel();}
    void createChannel(){NotificationManager m=getSystemService(NotificationManager.class);m.createNotificationChannel(new NotificationChannel("ai_infinity_bridge","AI Infinity Bridge",NotificationManager.IMPORTANCE_LOW));}
    Notification notification(String text){return new Notification.Builder(this,"ai_infinity_bridge").setContentTitle("AI Infinity Bridge").setContentText(text).setSmallIcon(android.R.drawable.stat_sys_upload).setOngoing(true).build();}
    @Override public int onStartCommand(Intent i,int flags,int startId){startForeground(NOTIFY_ID,notification("Connected bridge running")); if(!running){running=true;exec=Executors.newScheduledThreadPool(2);exec.scheduleWithFixedDelay(this::heartbeat,0,10,TimeUnit.SECONDS);exec.scheduleWithFixedDelay(this::poll,1,2,TimeUnit.SECONDS);}return START_STICKY;}
    String base(){return prefs.getString("server","https://ai-infinity-ca5e.onrender.com").replaceAll("/$","");} String rid(){return prefs.getString("runtime_id","");} String token(){return prefs.getString("bridge_token","");}
    JSONArray caps(){JSONArray a=new JSONArray();for(String x:new String[]{"device.ping","device.info","device.notify","device.open_url","browser.navigate","browser.click","browser.type","browser.submit","browser.extract"})a.put(x);return a;}
    void heartbeat(){if(!running||rid().isEmpty()||token().isEmpty())return;try{JSONObject b=new JSONObject();b.put("runtime_id",rid());b.put("bridge_token",token());b.put("healthy",true);b.put("capabilities",caps());JSONObject m=new JSONObject();m.put("platform","android");m.put("model",Build.MODEL);m.put("sdk",Build.VERSION.SDK_INT);b.put("metadata",m);BridgeHttp.post(base()+"/bridge/heartbeat",b,null);}catch(Exception ignored){}}
    void poll(){if(!running||rid().isEmpty()||token().isEmpty())return;try{JSONObject b=new JSONObject();b.put("runtime_id",rid());b.put("bridge_token",token());JSONObject r=BridgeHttp.post(base()+"/bridge/poll",b,null);if("command".equals(r.optString("status"))){JSONObject c=r.getJSONObject("command");execute(c);}}catch(Exception ignored){}}
    void execute(JSONObject cmd){String id=cmd.optString("id");String action=cmd.optString("action");JSONObject p=cmd.optJSONObject("command");if(p==null)p=new JSONObject();String status="completed";Object result= new JSONObject();String err="";try{
        if("device.ping".equals(action)){result=new JSONObject().put("pong",true);}
        else if("device.info".equals(action)){result=new JSONObject().put("platform","android").put("model",Build.MODEL).put("manufacturer",Build.MANUFACTURER).put("sdk",Build.VERSION.SDK_INT).put("app_version","1.0.0");}
        else if("device.notify".equals(action)){String text=p.optString("text",p.optString("message","AI Infinity notification")); notifyUser(text); result=new JSONObject().put("notified",true);}
        else if("device.open_url".equals(action)){openUrl(p.optString("url"));result=new JSONObject().put("opened",true).put("url",p.optString("url"));}
        else if("browser.navigate".equals(action)){openUrl(p.optString("url"));result=new JSONObject().put("opened",true).put("url",p.optString("url"));}
        else if("browser.click".equals(action)){BridgeAccessibilityService a=BridgeAccessibilityService.instance;if(a==null)throw new Exception("Android UI automation is not enabled");boolean ok=a.click(p.optString("selector"));if(!ok)throw new Exception("click target not found or not clickable");result=new JSONObject().put("clicked",true);}
        else if("browser.type".equals(action)){BridgeAccessibilityService a=BridgeAccessibilityService.instance;if(a==null)throw new Exception("Android UI automation is not enabled");boolean ok=a.type(p.optString("selector"),p.optString("text"));if(!ok)throw new Exception("type target not found or not editable");result=new JSONObject().put("typed",true);}
        else if("browser.submit".equals(action)){BridgeAccessibilityService a=BridgeAccessibilityService.instance;if(a==null)throw new Exception("Android UI automation is not enabled");String sel=p.optString("selector");boolean ok=a.click(sel);if(!ok && Build.VERSION.SDK_INT>=30){android.view.accessibility.AccessibilityNodeInfo root=a.getRootInActiveWindow();ok=root!=null&&aSubmit(root);}if(!ok)throw new Exception("submit target not found");result=new JSONObject().put("submitted",true);}
        else if("browser.extract".equals(action)){BridgeAccessibilityService a=BridgeAccessibilityService.instance;if(a==null)throw new Exception("Android UI automation is not enabled");result=new JSONObject().put("text",a.extract());}
        else {status="unsupported";err="unsupported action";}
    }catch(Exception e){status="failed";err=e.getMessage()==null?e.toString():e.getMessage();result=new JSONObject();}
    try{JSONObject b=new JSONObject();b.put("runtime_id",rid());b.put("bridge_token",token());b.put("command_id",id);b.put("status",status);b.put("result",result);if(!err.isEmpty())b.put("error",err);BridgeHttp.post(base()+"/bridge/result",b,null);}catch(Exception ignored){}
    }
    boolean aSubmit(android.view.accessibility.AccessibilityNodeInfo n){if(n.isFocused()&&n.isEditable())return n.performAction(android.view.accessibility.AccessibilityNodeInfo.ACTION_IME_ENTER);for(int i=0;i<n.getChildCount();i++){android.view.accessibility.AccessibilityNodeInfo x=n.getChild(i);if(x!=null&&aSubmit(x))return true;}return false;}
    void openUrl(String url)throws Exception{if(url==null||!(url.startsWith("https://")||url.startsWith("http://")))throw new Exception("only http/https URLs are allowed");Intent i=new Intent(Intent.ACTION_VIEW, Uri.parse(url));i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);startActivity(i);}
    void notifyUser(String text){Notification n=new Notification.Builder(this,"ai_infinity_bridge").setContentTitle("AI Infinity").setContentText(text).setSmallIcon(android.R.drawable.ic_dialog_info).setAutoCancel(true).build();((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).notify((int)(System.currentTimeMillis()%100000),n);}
    @Override public void onDestroy(){running=false;if(exec!=null)exec.shutdownNow();super.onDestroy();}
    @Override public android.os.IBinder onBind(Intent i){return null;}
}
