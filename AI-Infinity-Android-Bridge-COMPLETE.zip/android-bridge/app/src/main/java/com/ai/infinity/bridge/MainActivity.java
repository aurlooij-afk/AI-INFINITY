package com.ai.infinity.bridge;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.widget.*;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {
    static final String PREFS="ai_infinity_bridge";
    EditText server,name,code; TextView status; SharedPreferences prefs;
    @Override public void onCreate(Bundle b){ super.onCreate(b); setContentView(R.layout.activity_main);
        prefs=getSharedPreferences(PREFS,MODE_PRIVATE); server=findViewById(R.id.server); name=findViewById(R.id.name); code=findViewById(R.id.code); status=findViewById(R.id.status);
        server.setText(prefs.getString("server","https://ai-infinity-ca5e.onrender.com")); name.setText(prefs.getString("name","my-android"));
        if(prefs.getString("runtime_id","").length()>0) status.setText("Paired: "+prefs.getString("runtime_id","") );
        findViewById(R.id.pair).setOnClickListener(v->pair()); findViewById(R.id.start).setOnClickListener(v->startBridge()); findViewById(R.id.stop).setOnClickListener(v->stopService(new Intent(this,BridgeService.class)));
        findViewById(R.id.accessibility).setOnClickListener(v->startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)));
        if(android.os.Build.VERSION.SDK_INT>=33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED) requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},55);
    }
    void saveBase(){ prefs.edit().putString("server",server.getText().toString().trim().replaceAll("/$","")).putString("name",name.getText().toString().trim()).apply(); }
    void pair(){ saveBase(); final String base=server.getText().toString().trim().replaceAll("/$",""); final String nm=name.getText().toString().trim(); final String cd=code.getText().toString().trim().toUpperCase(); if(cd.isEmpty()){toast("Enter the pairing code shown by AI Infinity");return;}
        status.setText("Pairing…"); Executors.newSingleThreadExecutor().execute(()->{ try{
            JSONObject body=new JSONObject(); body.put("code",cd); body.put("kind","device"); body.put("name",nm); JSONArray caps=new JSONArray(); for(String x:new String[]{"device.ping","device.info","device.notify","device.open_url","browser.navigate","browser.click","browser.type","browser.submit","browser.extract"}) caps.put(x); body.put("capabilities",caps); JSONObject meta=new JSONObject(); meta.put("platform","android"); meta.put("model",android.os.Build.MODEL); meta.put("sdk",android.os.Build.VERSION.SDK_INT); body.put("metadata",meta);
            JSONObject out=BridgeHttp.post(base+"/activation/pair/claim",body,null); String token=out.getString("bridge_token"); String rid=out.getString("runtime_id"); prefs.edit().putString("bridge_token",token).putString("runtime_id",rid).apply(); runOnUiThread(()->status.setText("Paired ✓  "+rid));
        }catch(Exception e){runOnUiThread(()->status.setText("Pair failed: "+e.getMessage()));}});
    }
    void startBridge(){ saveBase(); if(prefs.getString("runtime_id","").isEmpty()){toast("Pair the phone first");return;} try{Intent i=new Intent(this,BridgeService.class); if(android.os.Build.VERSION.SDK_INT>=26) startForegroundService(i); else startService(i); status.setText("Bridge starting…");}catch(Exception e){status.setText("Start failed: "+e.getMessage());} }
    void toast(String s){Toast.makeText(this,s,Toast.LENGTH_LONG).show();}
}
