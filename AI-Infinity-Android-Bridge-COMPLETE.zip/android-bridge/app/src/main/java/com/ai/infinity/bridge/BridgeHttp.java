package com.ai.infinity.bridge;
import org.json.JSONObject; import java.io.*; import java.net.*; import java.nio.charset.StandardCharsets;
final class BridgeHttp {
 static JSONObject post(String url, JSONObject body, String token) throws Exception { HttpURLConnection c=(HttpURLConnection)new URL(url).openConnection(); c.setRequestMethod("POST"); c.setConnectTimeout(15000); c.setReadTimeout(30000); c.setDoOutput(true); c.setRequestProperty("Content-Type","application/json"); if(token!=null)c.setRequestProperty("Authorization","Bearer "+token); byte[] b=body.toString().getBytes(StandardCharsets.UTF_8); try(OutputStream o=c.getOutputStream()){o.write(b);} int code=c.getResponseCode(); InputStream in=code>=400?c.getErrorStream():c.getInputStream(); String s=read(in); if(code>=400)throw new IOException("HTTP "+code+" "+s); return s.isEmpty()?new JSONObject():new JSONObject(s); }
 static String read(InputStream in)throws Exception{ if(in==null)return ""; try(BufferedReader r=new BufferedReader(new InputStreamReader(in,StandardCharsets.UTF_8))){StringBuilder s=new StringBuilder();String l;while((l=r.readLine())!=null)s.append(l);return s.toString();}}
}
